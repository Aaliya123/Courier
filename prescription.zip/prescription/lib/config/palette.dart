import 'package:flutter/material.dart';

class Palette {
  static const Color primaryColor = Color(0xFF5cd3f7);
  static const Color IconColour = Color(0xFFA3A3A4);
  static const Color DefaultIconColour = Color(0xFF848484);
  static const Color DefaultBackgroundColour = Color(0xFFFEFEFE);
}
