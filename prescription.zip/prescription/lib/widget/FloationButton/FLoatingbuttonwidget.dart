// import 'package:flutter/material.dart';

// class FloationButtonWidget extends StatelessWidget {
//   FloationButtonWidget({
//     required this.ontap,
//     Key? key,
//   }) : super(key: key);
//   Function ontap;
//   @override
//   Widget build(BuildContext context) {
//     return FloatingActionButton(
//       onPressed: () {
//         ontap();
//       },
//       backgroundColor: Palette.primaryColor,
//       child: const Icon(
//         Icons.add,
//         color: Colors.white,
//       ),
//     );
//   }
// }
