import "package:flutter/material.dart";

class CustomTextWidget extends StatelessWidget {
  String text;
  double fontSize;
  int numberOfLines;
  Color textColor;
  // String fontFamily;
  FontWeight fontWeight;
  // double letterSpacing;
  // FontStyle fontStyle;
  // List<Shadow> shadows;
  TextAlign textAlign;
  // TextDecoration decoration;
  // Color decorationColor;
  // BoxFit fitHeight;
  // bool fittedBoxEnbl;
  // double decorationThickness;
  
  CustomTextWidget({
    required this.text,
    required this.fontSize,
     this.numberOfLines=1,
    this.textColor=Colors.black,
    // this.fontFamily,
    required this.fontWeight,
    // this.fontStyle,
    this.textAlign=TextAlign.start,
    // this.decoration,
    // this.decorationColor,
    // this.fitHeight,
    // this.fittedBoxEnbl = false,
    // this.decorationThickness,
  });
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      maxLines: numberOfLines,
      style: TextStyle(
          fontSize: fontSize,
          color: textColor,
          // fontFamily: fontFamily,
          fontWeight: fontWeight,
          // letterSpacing: letterSpacing,
          // shadows: shadows,
          // fontStyle: fontStyle,
          // decoration: decoration,
          // decorationColor: decorationColor,
          decorationStyle: TextDecorationStyle.solid),
      // overflow: TextOverflow.clip,
       overflow: TextOverflow.ellipsis,
      textAlign: textAlign,
    );
  }
}
