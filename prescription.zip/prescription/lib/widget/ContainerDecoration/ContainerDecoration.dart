


  import 'package:flutter/material.dart';

BoxDecoration ContainerDecoration(double radius, Color color) {
    return BoxDecoration(
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 3,
          blurRadius: 8,
          offset: Offset(0, 3), // changes position of shadow
        ),
      ],
      color: color,
      borderRadius: BorderRadius.all(Radius.circular(radius)),
    );
  }
