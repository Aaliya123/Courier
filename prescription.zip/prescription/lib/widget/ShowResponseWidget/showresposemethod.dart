
 import 'package:flutter/material.dart';

void ShowResponse(String Response, BuildContext context) {
  print("print");
    final snackBar = SnackBar(content: Text(Response), behavior: SnackBarBehavior.floating,backgroundColor: Colors.black.withOpacity(0.4),);

// Find the ScaffoldMessenger in the widget tree
// and use it to show a SnackBar.
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }