
import 'package:flutter/material.dart';
import 'package:prescription/config/palette.dart';

InputDecoration textFeildDecorationWidget(String text) {
  return InputDecoration(
    contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 10),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey.shade400)),
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey.shade400)),
    hintStyle: const TextStyle(fontSize: 15),
    hintText: text,
    focusedBorder: const OutlineInputBorder(
      borderSide: BorderSide(color: Palette.primaryColor),
    ),
    
  );
}
