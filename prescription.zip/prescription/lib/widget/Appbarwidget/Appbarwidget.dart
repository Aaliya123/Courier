

import 'package:flutter/material.dart';
import 'package:prescription/widget/CustomTextWidget/custom_text_widget.dart';

class AppBarWidget extends StatelessWidget {
  String text;
  Color color;
   AppBarWidget({
     this.text="",
     required this.color,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      brightness: Brightness.light,
      backgroundColor: Colors.white,
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: const Icon(
          Icons.arrow_back_ios,
          size: 20,
          color: Colors.black,
        ),
      ),
      actions: [
        Expanded(
          flex: 1,
          child: Container()),
        Expanded(
          flex: 2,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CustomTextWidget(
                  text:text, fontSize: 15, fontWeight: FontWeight.bold),
            ],
          ),
        ),
        Expanded(flex: 1, child: Container())
      ],
    );
  }
}
