//
import 'package:flutter/material.dart';
import 'package:prescription/Annimation/loginAnnimation.dart';
import 'package:prescription/Screens/Admin/index.dart';
import 'package:prescription/Screens/AllPrescription/index.dart';
import 'package:prescription/Screens/UploadPresciption/index.dart';
import 'package:prescription/config/palette.dart';
import 'package:prescription/widget/CustomTextWidget/custom_text_widget.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<DashboardObject> dashboard = <DashboardObject>[
      DashboardObject("Upload Prescription", "assets/images/uploadImage.png", () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) {
              return const UploadPrescription();
            },
          ),
        );
      }),
      DashboardObject("All Prescription", "assets/images/prescription.png", () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) {
              return const AllPrescription();
            },
          ),
        );
      }),
       DashboardObject("Admin", "assets/images/pill.png", () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) {
              return const Admin();
            },
          ),
        );
      }),
     
       
    ];
    return Scaffold(
      body: Container(
       color: Palette.primaryColor,
        child: Column(
          children: [
            Expanded(
                flex: 2,
                child: FadeAnimation(
                  1,
                  Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.all(20),
                    width: double.infinity,
                    decoration:const BoxDecoration(
                      color: Palette.primaryColor,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon:const Icon(
                              Icons.arrow_back_ios,
                              color: Colors.white,
                            )),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // SizedBox(height: 20,),
                            CustomTextWidget(
                              text: "Welcome",
                              fontSize: 15,
                              fontWeight: FontWeight.normal,
                              textColor: Colors.white,
                            ),
                            CustomTextWidget(
                                text: "Username",
                                fontSize: 22,
                                textColor: Colors.white,
                                fontWeight: FontWeight.normal),
                          ],
                        ),
                      ],
                    ),
                  ),
                )),
            Expanded(
                flex: 6,
                child: FadeAnimation(
                  1.2,
                   Container(
                     width: double.infinity,
                    padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                    decoration:const BoxDecoration(
                     color: Colors.white,
                     borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
                    ),
                    child: GridView.builder(
                        itemCount: dashboard.length,
                        gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 2 / 2,
                            crossAxisSpacing: 10.0,
                            mainAxisSpacing: 10.0),
                        itemBuilder: (BuildContext, index) => listWidget(index: index,dashboard: dashboard)),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class listWidget extends StatelessWidget {
   listWidget({
    Key? key,
    required this.index,
    required this.dashboard,
  }) : super(key: key);
  int index;
  final List<DashboardObject> dashboard;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: dashboard[index].ontap,
      child: Container(
            padding: EdgeInsets.all(5),
            decoration:const BoxDecoration(
              color: Palette.DefaultBackgroundColour,
              // boxShadow: [
              //   BoxShadow(
              //     color: Colors.grey.withOpacity(0.2),
              //     spreadRadius: 3,
              //     blurRadius: 5,
              //     offset: Offset(
              //         0, 3), // changes position of shadow
              //   ),
              // ],
              borderRadius:
                  BorderRadius.all(Radius.circular(15)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(dashboard[index].image),
                CustomTextWidget(
                    text: dashboard[index].title,
                    fontSize: 15,
                    fontWeight: FontWeight.bold),
              ],
            ),
          ),
    );
  }
}

class DashboardObject {
  final String image;
  final String title;
  Function()? ontap;
  DashboardObject(this.title, this.image, this.ontap);
}
