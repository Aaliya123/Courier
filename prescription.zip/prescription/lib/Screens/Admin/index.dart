import 'package:flutter/material.dart';
import 'package:prescription/Screens/AllPrescription/ViewPrescription.dart';
import 'package:prescription/config/palette.dart';
import 'package:prescription/widget/Appbarwidget/Appbarwidget.dart';
import 'package:prescription/widget/ContainerDecoration/ContainerDecoration.dart';
import 'package:prescription/widget/CustomTextWidget/custom_text_widget.dart';

class Admin extends StatefulWidget {
  const Admin({Key? key}) : super(key: key);

  @override
  State<Admin> createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Palette.DefaultBackgroundColour,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(48.0),
          child: AppBarWidget(
            text: "Prescription",
            color: Palette.primaryColor.withOpacity(0.02),
          )),
      body: ListView.builder(
          itemCount: 3,
          itemBuilder: (BuildContext buildContext, index) => HotelsWidget()),
    );
  }
}

class HotelsWidget extends StatelessWidget {
  const HotelsWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ViewPrescription()));
      },
      child: Container(
        height: 250,
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: ContainerDecoration(20, Colors.white),
        child: Column(
          children: [
            Expanded(
              flex: 3,
              child: Container(
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage("assets/images/bedroom.jpg"))),
              ),
            ),
            Expanded(
              flex: 2,
              child: Container(
                margin:const EdgeInsets.all(15),
                child: Row(
                  children: [
                    Expanded(
                      child: CustomTextWidget(
                          text: "Lux Hotel Tornoto",
                          fontSize: 15,
                          fontWeight: FontWeight.w700),
                    ),
                    Expanded(
                      child: Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            padding:const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Palette.primaryColor),
                            child: IconButton(
                              icon:const Icon(Icons.chat,color: Colors.white,),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            ViewPrescription(addText: true,)));
                              },
                            ),
                          )),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
