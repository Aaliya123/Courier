import 'package:prescription/config/palette.dart';
import 'package:prescription/widget/Appbarwidget/Appbarwidget.dart';
import 'package:prescription/widget/Button/ButtonWidget.dart';
import 'package:prescription/widget/ContainerDecoration/ContainerDecoration.dart';
import 'package:prescription/widget/CustomTextWidget/custom_text_widget.dart';
import 'package:flutter/material.dart';
import 'package:prescription/widget/inputTextDecorationWidget/inputfeildDecoration.dart';

class NewContact extends StatefulWidget {
  const NewContact({Key? key}) : super(key: key);

  @override
  _NewContactState createState() => _NewContactState();
}

class _NewContactState extends State<NewContact> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(48.0),
            child: AppBarWidget(
              text: "Add New Contact",
              color: Colors.white,
            )),
        body: Container(
            padding: EdgeInsets.symmetric(horizontal: 40),
            height: MediaQuery.of(context).size.height - 50,
            width: double.infinity,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(
                    height: 100,
                  ),
                  TextFormField(
                    style: TextStyle(fontSize: 14),
                    cursorColor: Palette.primaryColor,
                    decoration: textFeildDecorationWidget('Name'),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    style: TextStyle(fontSize: 14),
                    keyboardType: TextInputType.number,
                    cursorColor: Palette.primaryColor,
                    decoration: textFeildDecorationWidget('Mobile Number'),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    style: TextStyle(fontSize: 14),
                    keyboardType: TextInputType.emailAddress,
                    cursorColor: Palette.primaryColor,
                    decoration: textFeildDecorationWidget('Email'),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Buttonwidget(
                    text: "Save",
                    OnPress: () {
                      // Navigator.push(
                      //     context,
                      //     MaterialPageRoute(
                      //         builder: (context) => Home()));
                    },
                  )
                ],
              ),
            )));
  }
}
