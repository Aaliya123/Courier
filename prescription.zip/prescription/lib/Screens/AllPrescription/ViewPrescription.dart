import 'package:flutter/material.dart';
import 'package:prescription/config/palette.dart';
import 'package:prescription/widget/Button/ButtonWidget.dart';
import 'package:prescription/widget/CustomTextWidget/custom_text_widget.dart';

class ViewPrescription extends StatefulWidget {
  bool addText;
  ViewPrescription({
    Key? key,
    this.addText = false,
  }) : super(key: key);

  @override
  _ViewPrescriptionState createState() => _ViewPrescriptionState();
}

class _ViewPrescriptionState extends State<ViewPrescription> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Column(
              children: [
                UpperBody(),
                Expanded(
                  flex: 3,
                  child: Container(),
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  flex: 5,
                  child: Container(),
                ),
                Expanded(
                  flex: 4,
                  child: Container(
                    decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(40),
                          topRight: Radius.circular(40)),
                      color: Colors.white,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            margin: const EdgeInsets.all(15),
                            child: widget.addText
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      const Text(
                                        "Prescription",
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.black87),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      TextField(
                                        maxLines: 6,
                                        decoration: InputDecoration(
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                  vertical: 0, horizontal: 10),
                                          enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.grey.shade400)),
                                          focusedBorder:
                                              const OutlineInputBorder(
                                            borderSide: BorderSide(
                                              color: Palette.primaryColor,
                                            ),
                                          ),
                                          border: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.grey.shade400)),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 30,
                                      ),
                                      Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 40),
                                          child: Buttonwidget(
                                            text: "Send",
                                            OnPress: () {
                                              // Navigator.push(
                                              //     context,
                                              //     MaterialPageRoute(
                                              //         builder: (context) => Home()));
                                            },
                                          ))
                                    ],
                                  )
                                : 
                              Container(
                                width: double.infinity,
                                    child: Column(
                                      children: [
                                        CustomTextWidget(
                                            text: "Prescription",
                                            fontSize: 18,
                                            fontWeight: FontWeight.w600),
                                            CustomTextWidget(
                                            text: "Prescription",
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ],
                                    ),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsWidget extends StatelessWidget {
  const DetailsWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomTextWidget(
            numberOfLines: 6,
            text: "Services",
            fontSize: 18,
            fontWeight: FontWeight.bold,
            // textColor: Palette.DefaultIconColour,
          ),
          Container(
            height: 150,
            child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: 5,
                itemBuilder: (BuildContext buildContext, index) => Container(
                      height: 100,
                      width: 150,
                      margin: const EdgeInsets.all(5),
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                          image: DecorationImage(
                              image: AssetImage("assets/images/bedroom.jpg"),
                              fit: BoxFit.cover)),
                    )),
          ),
        ],
      ),
    );
  }
}


class UpperBody extends StatelessWidget {
  const UpperBody({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 5,
      child: Stack(
        children: [
          Container(
            decoration:const BoxDecoration(
                image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage("assets/images/bedroom.jpg"))),
          ),
          Column(
            children: [
              Expanded(
                  flex: 1,
                  child: Container(
                    padding:const EdgeInsets.all(15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Container(
                              decoration:const BoxDecoration(
                                  color: Colors.white, shape: BoxShape.circle),
                              child: IconButton(
                                color: Palette.primaryColor,
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon:const Icon(
                                  Icons.arrow_back_ios_new,
                                ),
                              )),
                        ),
                             Expanded(flex: 3, child: Container()),
                      ],
                    ),
                  )),
              Expanded(flex: 3, child: Container()),
            ],
          )
        ],
      ),
    );
  }
}
