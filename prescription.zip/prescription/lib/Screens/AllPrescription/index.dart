import 'package:flutter/material.dart';
import 'package:prescription/config/palette.dart';
import 'package:prescription/widget/Appbarwidget/Appbarwidget.dart';
import 'package:prescription/widget/ContainerDecoration/ContainerDecoration.dart';
import 'package:prescription/widget/CustomTextWidget/custom_text_widget.dart';

import 'ViewPrescription.dart';

class AllPrescription extends StatefulWidget {
  const AllPrescription({Key? key}) : super(key: key);

  @override
  State<AllPrescription> createState() => _AllPrescriptionState();
}

class _AllPrescriptionState extends State<AllPrescription> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(48.0),
          child: AppBarWidget(
            text: "All Prescription",
            color: Palette.primaryColor.withOpacity(0.02),
          )),
      body: Container(
        color: Colors.white,
        child: ListView.builder(
            itemCount: 5,
            itemBuilder: (BuildContext, index) => InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return  ViewPrescription();
                        },
                      ),
                    );
                  },
                  child: Container(
                      height: 150,
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            spreadRadius: 3,
                            blurRadius: 8,
                            offset: const Offset(
                                0, 3), // changes position of shadow
                          ),
                        ],
                        image: const DecorationImage(
                            fit: BoxFit.cover,
                            image: AssetImage(
                              "assets/images/bedroom.jpg",
                            )),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10)),
                      )
                      // ContainerDecoration(
                      //   10,
                      //   Palette.DefaultBackgroundColour,
                      // ),

                      ),
                )),
      ),
    );
  }
}
