import 'dart:io';

import 'package:flutter/material.dart';
import 'package:prescription/config/palette.dart';
import 'package:prescription/widget/Appbarwidget/Appbarwidget.dart';
import 'package:prescription/widget/Button/ButtonWidget.dart';
import 'package:image_picker/image_picker.dart';

class UploadPrescription extends StatefulWidget {
  const UploadPrescription({Key? key}) : super(key: key);

  @override
  _UploadPrescriptionState createState() => _UploadPrescriptionState();
}

class _UploadPrescriptionState extends State<UploadPrescription> {


 File? imageFile;

/// Get from gallery
  _getFromGallery() async {
    // ignore: deprecated_member_use
    PickedFile? pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      maxHeight: 1800,
    );
    if (pickedFile != null) {
      setState(() {
        imageFile = File(pickedFile.path);
      });
    }
  }

  /// Get from Camera
  _getFromCamera() async {
    // ignore: deprecated_member_use
    PickedFile? pickedFile = await ImagePicker().getImage(
      source: ImageSource.camera,
      maxWidth: 1800,
      maxHeight: 1800,
    );
    if (pickedFile != null) {
      setState(() {
        imageFile = File(pickedFile.path);
      });
    }
  }

  bool isSubmit = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(48.0),
          child: AppBarWidget(
            text: "Upload  Prescription",
            color: Palette.primaryColor.withOpacity(0.02),
          )),
      body: Column(
        children: [
          Expanded(
            flex: 4,
            child: Container(
              width: double.infinity,
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.all(10),
                // decoration: BoxDecoration(
                //   boxShadow: [
                //     BoxShadow(
                //       color: Colors.grey.withOpacity(0.2),
                //       spreadRadius: 3,
                //       blurRadius: 8,
                //       offset: const Offset(0, 3), // changes position of shadow
                //     ),
                //   ],
                //   borderRadius: const BorderRadius.all(Radius.circular(10)),
                // ),
                child:imageFile!=null? Image.file(
                imageFile!,
                fit: BoxFit.cover,
              ):const Center(child: Text("no image")),
                ),
          ),
          const SizedBox(
            height: 30,
          ),
          Expanded(
              flex: 2,
              child: Column(
                children: [
                  if (isSubmit)
                    Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 40),
                        child: Buttonwidget(
                          text: "Upload From Gallery",
                          OnPress: () {
                            setState(() {
                              _getFromGallery();
                              isSubmit = false;
                            });
                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) => Home()));
                          },
                        )),
                  const SizedBox(
                    height: 10,
                  ),
                  if (isSubmit)
                    Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 40),
                        child: Buttonwidget(
                          text: "Upload From Camera",
                          color: Colors.white,
                          textcolor: Colors.black,
                          OnPress: () {
                            setState(() {
                              _getFromCamera();
                              isSubmit = false;
                              
                            });
                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) => Home()));
                          },
                        )),
                  if (isSubmit == false)
                    Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 40),
                        child: Buttonwidget(
                          text: "Send",
                          OnPress: () {
                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) => Home()));
                          },
                        ))
                ],
              ))
        ],
      ),
    );
  }
}
