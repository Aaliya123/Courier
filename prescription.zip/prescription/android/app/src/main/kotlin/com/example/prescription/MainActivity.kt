package com.example.prescription

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
